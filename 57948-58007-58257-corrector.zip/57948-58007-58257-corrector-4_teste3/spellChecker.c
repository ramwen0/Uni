#include "spellChecker.h"

int CheckPrime(int n){ //function checks in a number N is prime or not
    int flag = 1; // initially, flag is set to true or 1
    for (int i = 2; i <= n / 2; i++) { // iterate through 2 to N/2 - if divisible, flag is false
        if (n % i == 0) {
            flag = 0;
            break;
        }
    }

    if (flag) {
        return n;
    }
    else {
        return 0;
    }
}

int GreatestPrime(int size){ //using the previous function, it finds the greatest prime, counting from table_size, used when rehashing
    int greatest = 0;
    while (size > 1)
    {
        if(CheckPrime(size)){
            if(greatest < CheckPrime(size)) greatest = CheckPrime(size);
            break;
        }
        size--;
    }
    return greatest;
}

item ModifyItem(int newKey, const type *newWord){ //modifies an item by its key value and word, and returns the adulterated one
    item newItem;
    newItem.key = newKey;

    if (newKey == EMPTY_SLOT){
        newItem.word = NULL;
    }else{
        newItem.word = strdup(newWord);
    }
    return newItem;
}

int GenerateKey(const type *word, int attempt, int size, int mode){ //hash function and access definition - switch case to alternate between linear and quadratic
    unsigned long hash = 5381;
    type c;
    while ((c = *word++))
        hash = (hash * 33) + c; // hash * 33 + c

    switch (mode)
    {
    case LINEAR_ACCESS:
        return (hash + attempt) % size;
        break;
    
    case QUADRATIC_ACCESS:
        return (hash + ((attempt + 1) * (attempt + 1))) % size;
        break;

    default:
        printf("Choose an available option!\n");
        return -3;
        break;

    }    

}


table *InitTable(const size_t tableSize, int type){ // init - all entries set to NULL, keys to EMPTY_KEY
    table *ht = malloc(sizeof(table));

    if (ht == NULL){
        printf("Out of Memory!");

        return NULL;
    }

    ht->type = type;
    ht->size = tableSize;

    if (type == TABLE_TYPE_ITEM){
        ht->itemElements = (item *)calloc(tableSize, sizeof(item));

        if (ht->itemElements == NULL){
            printf("Out of Memory!");
            free(ht);

            return NULL;
        }

        for (size_t i = 0; i < tableSize; i++){
            ht->itemElements[i] = ModifyItem(EMPTY_SLOT, NULL);

        }

    }
    else if (type == TABLE_TYPE_SUGESTIONS){
        ht->sugElements = (sugestions *)calloc(tableSize, sizeof(sugestions));

        if (ht->sugElements == NULL){
            printf("Out of Memory!");
            free(ht);

            return NULL;
        }

        for (size_t i = 0; i < tableSize; i++){
            ht->sugElements[i].words = InitText(MAX_TEXT_SIZE, MAX_WORD_SIZE, MAX_SIZE_TEXT);
            ht->sugElements[i].key = EMPTY_SLOT;
            ht->sugElements[i].nSugestions = 0;
            
        }

    }

    ht->count = 0;
    ht->rpCount = 0;
    ht->lf = 0;
    ht->rhCount = 0;

    return ht;
}


void DeleteItem(table *ht, const int key){ //deletes an item based in its key, word becomes NULL and key becomes DELETED_KEY
    if (ht->type == TABLE_TYPE_ITEM){
        if (ht->itemElements[key].key != EMPTY_SLOT && ht->itemElements[key].key != DELETED_SLOT){
            ht->itemElements[key].key = DELETED_SLOT;

            free(ht->itemElements[key].word);
            ht->itemElements[key].word = NULL;

            printf("\nDeleted succesfuly key %d!", key);
            ht->count--;

            return;

        }

    }
    else if (ht->type == TABLE_TYPE_SUGESTIONS){
        if (ht->sugElements[key].key != EMPTY_SLOT && ht->sugElements[key].key != DELETED_SLOT){
            ht->sugElements[key].key = DELETED_SLOT;

            for (int i = 0; i < ht->sugElements->words->nWords; i++){
                free(ht->sugElements[key].words->finalText[i]);
                ht->sugElements[key].words->finalText[i] = NULL;

            }

            printf("\nDeleted succesfuly key %d!", key);
            ht->count--;

            return;

        }

        return;

    }

    printf("Failed to delete key %d!\n", key);

    return;
}


void FreeTable(table *ht){ // frees up all memory used
    int count = 0;

    if (ht == NULL) return;

    printf("\nStarting freeing process...\n");

    for(size_t i = 0; i < ht->size; i++){
        DeleteItem(ht, i);
        count++;

    }

    if (ht->type == TABLE_TYPE_ITEM){
        free(ht->itemElements);

    }
    else if (ht->type == TABLE_TYPE_SUGESTIONS){
        for (int i = 0; i < ht->size; i++){
            free(ht->sugElements[i].words->finalText);
            free(ht->sugElements[i].words);

        }

        free(ht->sugElements);
        
    }

    free(ht);

    printf("\n\nFreed sucessfuly %d items!\n", count);
}


void PrintTable(table *ht){ // print - makes a print of table if the table is valid
    if((ht->type == TABLE_TYPE_ITEM && ht->itemElements != NULL) || (ht->type == TABLE_TYPE_SUGESTIONS && ht->sugElements != NULL)){

       printf("\n- - - - = = = = | T A B L E   S T A R T | = = = = - - - -\n\n");
        for (size_t i = 0; i < ht->size; i++){
            if (ht->type == TABLE_TYPE_ITEM){
                if(ht->itemElements[i].key != EMPTY_SLOT && ht->itemElements[i].key != DELETED_SLOT){
                    printf("%d -> %s\n", ht->itemElements[i].key, ht->itemElements[i].word); 

                }

            }
            else if (ht->type == TABLE_TYPE_SUGESTIONS){ //for the suggestion table, the print is a changed version of the above
                if(ht->sugElements[i].key != EMPTY_SLOT && ht->sugElements[i].key != DELETED_SLOT){
                    printf("%d -> %s -> {%s", ht->sugElements[i].key, ht->sugElements[i].words->finalText[0], ht->sugElements[i].words->finalText[1]); 

                    for (int j = 1; j < ht->sugElements[i].nSugestions; j++){ 
                        printf(", %s", ht->sugElements[i].words->finalText[j + 1]);

                    }

                    printf("}\n");

                }

            }

            

        }
        printf("\n- - - - = = = = | T A B L E   E N D | = = = = - - - -\n\n");

        printf("- - - - = = = = | D A T A   S T A R T | = = = = - - - -\n\n"); //data stats for the table
        printf("Table Size: %d\n", ht->size);
        printf("Entries: %d\n", ht->count);
        printf("Repeated Entries: %d\n", ht->rpCount);
        printf("Total Entries: %d\n", ht->count + ht->rpCount);
        printf("Space Left: %d\n", ht->size - ht->count);
        printf("Load Factor: %.2f\n", ht->lf); 
        printf("Reahshes Counter: %d\n", ht->rhCount);
        printf("\n- - - - = = = = | D A T A   E N D | = = = = - - - -\n\n");
    }
    else{
        printf("hash table not avaliable.\n");

    }
    
}

void Rehash(table *ht, int mode){ // takes the greatest valid prime - between 1 and the table size, doubles that, makes a new table with that table size, and re-inserts all the items
    if (ht->lf < REHASHING_LIM){
        return;

    }

    printf("Rehashing Table!\n");

    //getting greatest prime, updating table size
    int newSize = (2 * GreatestPrime(ht->size)), oldTableCount = ht->count; 
    table *newTable = InitTable(newSize, ht->type);
    
    newTable->rpCount = ht->rpCount;
    
    for (int i = 0; i < ht->size; i++){
        if(ht->type == TABLE_TYPE_ITEM){ //insert for the items-based table
            if (ht->itemElements[i].key != EMPTY_SLOT && ht->itemElements[i].key != DELETED_SLOT){
                InsertItem(newTable, ht->itemElements[i].word, NULL, mode, INSERT_NORMAL, i);

            }

        }
        else if (ht->type == TABLE_TYPE_SUGESTIONS){ //insert for the sugestions-based table
            if (ht->sugElements[i].key != EMPTY_SLOT && ht->sugElements[i].key != DELETED_SLOT){
                InsertItem(newTable, ht->sugElements[i].words->finalText[0], ht->sugElements, mode, INSERT_NORMAL, i);

            }

        }

    }
    
    //freeing memory used during the process
    if(ht->type == TABLE_TYPE_ITEM){
        free(ht->itemElements);
    }
    else if (ht->type == TABLE_TYPE_SUGESTIONS){
        free(ht->sugElements);
    }

    //making all the data from the old table the same as the new one
    ht->size = newTable->size;
    ht->count = newTable->count;
    ht->itemElements = newTable->itemElements;
    ht->sugElements = newTable->sugElements;
    ht->rpCount = newTable->rpCount;
    ht->lf = newTable->lf;      
    ht->rhCount++;      

    //printf("\nRehashed succesfuly %d words of %d from the old table!\n", newTable->count, oldTableCount);

    free(newTable); //freeing the new table
}


int InsertItem(table *ht, type *word, sugestions *sug, int hashingMode, int insertMode, int ogKey) { //inserting a new item into the provided table, by its word
    for (int attempt = 0; ; attempt++){
        int currentKey = GenerateKey(word, attempt, ht->size, hashingMode); //generating a base key for the word

        if (ht->type == TABLE_TYPE_ITEM){ //if item-based table
            item testItem = ht->itemElements[currentKey];

            if (testItem.key == EMPTY_SLOT || testItem.key == DELETED_SLOT){ // Insert word in the valid key
                ht->itemElements[currentKey] = ModifyItem(currentKey, word);
                ht->count++;
                ht->lf = (float)ht->count / (float)ht->size; 

                //printf("Size: %d || Count: %d || RPCount: %d || LF: %.2f || RHCount: %d\n", ht->size, ht->count, ht->rpCount, ht->lf, ht->rhCount);

                return currentKey; 

            }
            else if (strcmp(testItem.word, word) == 0){ // Encountered a repeated word 
                ht->rpCount++;
                return -3;
            }


        }
        else if (ht->type == TABLE_TYPE_SUGESTIONS){ //if sugestion-based table
            sugestions testItem = ht->sugElements[currentKey];

            if (testItem.key == EMPTY_SLOT || testItem.key == DELETED_SLOT){ // Insert word in the valid key
                if (insertMode == INSERT_FIRST_TIME){
                    ht->sugElements[currentKey].words->finalText[0] = word; //updating the base word for the suggestions list

                    ht->sugElements[currentKey].nSugestions = 0; //reseting sugestion count
                    ht->sugElements[currentKey].words->nWords = MAX_TEXT_SIZE;

                }
                else if (insertMode == INSERT_NORMAL){
                    printf("Expected: %s, Received: %s\n", word, sug[ogKey].words->finalText[0]); //managing collisions
                    for (int j = 0; j < sug[ogKey].nSugestions + 1; j++){
                        ht->sugElements[currentKey].words->finalText[j] = sug[ogKey].words->finalText[j];
                    }

                    ht->sugElements[currentKey].nSugestions = sug[ogKey].nSugestions;
                    ht->sugElements[currentKey].words->nWords = sug[ogKey].words->nWords;

                }

                ht->sugElements[currentKey].key = currentKey;
                ht->count++;
                ht->lf = (float)ht->count / (float)ht->size; 

                //printf("Size: %d || Count: %d || RPCount: %d || LF: %.2f || RHCount: %d\n", ht->size, ht->count, ht->rpCount, ht->lf, ht->rhCount);

                return currentKey; 

            }
            else if (strcmp(testItem.words->finalText[0], word) == 0){ // Encountered a repeated word 
                ht->rpCount++;
                return -3;

            }


        }

        if (attempt != 0 && currentKey == ogKey){ // Come back to start, error 
            return -3;    
                                         
        }
    }
}


void InitFile(type *fileName, table *ht, int mode){ //called to open the dictionary file and manage insertion from there
    FILE *file = fopen((char *)fileName, "r");

    if (file == NULL){
        printf("Error opening file!\n");

        FreeTable(ht);

        return;

    }

    type word[MAX_WORD_SIZE]; //word buffer
    int read = 0; //words read counter

    while (fscanf(file, "%s", word) != EOF){ //reading through the dictionary, word by word
        read++;

        InsertItem(ht, word, NULL, mode, INSERT_FIRST_TIME, EMPTY_SLOT); //insert the word into the table

        Rehash(ht, mode); //if needed, rehash
    }

    //printf("\nwords read: %d\n", read);

    fclose(file);
}

int CheckWord(table *ht, const type *word, int mode){ //checks if a word exists in the hash table
    int key = GenerateKey(word, 0, ht->size, mode); //generates base key

    if ((ht->type == TABLE_TYPE_ITEM && ht->itemElements[key].word == NULL) || (ht->type == TABLE_TYPE_SUGESTIONS && ht->sugElements[key].words->finalText[0] == NULL)){
        //wprintf(L"%d -> '%ls'\n", key, word);
        //wprintf(L"No match for '%ls'!\n\n", word);

        return 0; //if the key id null, return

    }

    type tableWord[MAX_WORD_SIZE];
    tableWord[0] = '\0';

    if (ht->type == TABLE_TYPE_ITEM){
        strcpy(tableWord, ht->itemElements[key].word); //copying the word corresponding to the key to the tableWord variable

    }
    else if (ht->type == TABLE_TYPE_SUGESTIONS){
        strcpy(tableWord, ht->sugElements[key].words->finalText[0]); //copying the word corresponding to the key to the tableWord variable
    }
    
    if (strcmp(word, tableWord) == 0){ //if both words are the same, expected outcome

        return 1;

    }
    else{
        for (int i = 0; i < ht->size; i++){
            if (ht->type == TABLE_TYPE_ITEM){
                if (ht->itemElements[i].word != NULL){
                    strcpy(tableWord, ht->itemElements[i].word);

                    if (strcmp(word, tableWord) == 0){ //if both words are the same, the word was found, but not in the expected key

                        return 1;

                    }

                }

            }
            else if (ht->type == TABLE_TYPE_SUGESTIONS){
                if (ht->sugElements[i].words->finalText[0] != NULL){
                    strcpy(tableWord, ht->sugElements[i].words->finalText[0]);
                    if (strcmp(word, tableWord) == 0){ //same as above, for the sugestions-based table

                        return 1;

                    }

                }

            }       

        }

        //if none of the above, word did not return as expected
        return 0;

    }

}

type **AllocateText(int textSize, int wordSize){
    type **newText = (type **)calloc(textSize, sizeof(type *));

    if (newText == NULL){
        printf("Out of Memory!\n");

        return NULL;
    }

    for (int i = 0; i < textSize; i++){
        newText[i] = (type *)calloc(wordSize, sizeof(type));

        if (newText[i] == NULL){
            printf("Out of Memory!\n");

            for (int j = 0; j < i; j++) {
                free(newText[j]);

            }
            free(newText);

            return NULL;
        }

        newText[i][0] = L'\0';


    }

    return newText;

}


text *InitText(int textSize, int wordSize, int allocationMode){ //initialize text, based on the MAX_TEXT_SIZE and SIZED_TEXT flags
    text *newText = (text *)malloc(sizeof(text));

    if (newText == NULL){
        printf("Out of Memory!\n");

        return NULL;

    }

    if (allocationMode == MAX_SIZE_TEXT){
        newText->finalText = AllocateText(MAX_TEXT_SIZE, wordSize);
        newText->nWords = MAX_TEXT_SIZE;

    }
    else if(allocationMode == SIZED_TEXT){
        newText->finalText = AllocateText(textSize, wordSize);
        newText->nWords = 0;

    }

    if (newText->finalText == NULL){
        printf("Out of Memory!\n");

        free(newText);

        return NULL;

    }

    return newText;

}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
text *GetTextWords(type *fileName, int textAllocationMode){ //getting all the words in a .txt file, similar to how initFile handles word separation, but with spacs instead of newlines
    FILE *file = fopen((char *)fileName, "r");

    if (file == NULL){
        printf("Didnt find any file named '%s'!\n", fileName);

        return NULL;
    }

    int countWords = 0;
    type **processText = AllocateText(MAX_WORD_SIZE, MAX_WORD_SIZE);

    if (processText == NULL){
        printf("Out of Memory!\n");

        fclose(file);

        return NULL;
    }

    type string[MAX_WORD_SIZE];

    while (fscanf(file, "%s", string) != EOF){
        strcpy(processText[countWords], string); //storing all the words found in their corresponding index
        countWords++; //incrementing index

        if (countWords > MAX_TEXT_SIZE){
            break;

        }

    }

    text *newText;

    if (textAllocationMode == MAX_SIZE_TEXT){
        newText = InitText(MAX_TEXT_SIZE, MAX_WORD_SIZE, textAllocationMode);

        if (newText == NULL){
            printf("Out of Memory!\n");

            return NULL;

        }

        newText->finalText = processText; //copying the values compiled ealier to the finalText variable in the newText instance

    }
    else if (textAllocationMode == SIZED_TEXT){
        newText = InitText(countWords, MAX_WORD_SIZE, textAllocationMode);

        if (newText == NULL){
            printf("Out of Memory!\n");

            return NULL;

        }

        newText->nWords = countWords;
        newText->finalText = AllocateText(newText->nWords, MAX_WORD_SIZE);

        if (newText->finalText == NULL){
            printf("Out of Memory!\n");

            free(processText);
            free(newText);
            fclose(file);

            return NULL;
        }

        for (int i = 0; i < newText->nWords; i++){
            strcpy(newText->finalText[i], processText[i]);

        }

        for (int i = MAX_WORD_SIZE; i >= 0; i--){
            free(processText[i]);
        }

        free(processText);

    }

    return newText;
}

type *AddSugestion(type *word, int position, const type *cAdd) { //function to add a character to a word, in a specific position
    type *newString = (type *)malloc(MAX_WORD_SIZE * sizeof(type));

    if (newString == NULL){
        printf("Out of Memory!\n");

        return NULL;

    }

    strncpy(newString, word, position); //copying the number of chars in position (int) of the word to the newString variable
    newString[position] = cAdd[0]; //start adding character
    strcpy(newString + position + 1, word + position); //copying the word + position index 1 position ahead, creating a blank space to house the added character 

    return newString;

}



type *RemSugestion(type *word, int position){ //function to remove a character from a word
    type *newString = (type *)malloc(MAX_WORD_SIZE * sizeof(type));

    if (newString == NULL){
        printf("Out of Memory!\n");

        return NULL;

    }

    strncpy(newString, word, position); //copying the number of chars in position (int) of the word to the newString variable
    strcpy(newString + position, word + position + 1); //copying the word + position + 1 index 1 position behind, eliminating a space in the word, and removing a character

    return newString;
    
}


type *SwapSugestion(type *word, int position){ //function ti swap characters
    type *newString = malloc(MAX_WORD_SIZE * sizeof(type)), tmp = word[position]; 
    strcpy(newString, word);

    //swapping with bubblesort, if the next character isnt the end of the word
    if (word[position + 1] != '\0'){
        newString[position] = word[position + 1];
        newString[position + 1] = tmp;

    }

    return newString;
    
}


void VerifySugestion(table *dictionary, table *sugTable, type *word, int hashingMode, int position, const type *charAddition, int sugRule, int key){ //function to verify the found suggestions 
    type possibleSugestion[MAX_WORD_SIZE]; 
    possibleSugestion[0] = '\0';

    switch (sugRule)
    {
    case ADD_MODE:
        strcpy(possibleSugestion, AddSugestion(word, position, charAddition));
        break;
    
    case REM_MODE:
        strcpy(possibleSugestion, RemSugestion(word, position));
        break;

    case SWAP_MODE:
        strcpy(possibleSugestion, SwapSugestion(word, position));
        break;
        
    default:
        printf("Choose a valid rule!\n");
        return;
    }

    if (possibleSugestion == NULL){
        printf("There was a problem generating a sugestion!\n");

        FreeTable(dictionary);

        return;

    }

    if (CheckWord(dictionary, possibleSugestion, LINEAR_ACCESS)){
        printf("New Sugestion: %s\n", possibleSugestion);

        sugTable->sugElements[key].nSugestions++;

        strcpy(sugTable->sugElements[key].words->finalText[sugTable->sugElements[key].nSugestions], possibleSugestion);

    }
    else {
        //printf("The sugestion '%s' is invalid!\n", possibleSugestion);

    }

}


void CreateSugestions(type *word, table *dictionary, table *sugTable, int hashingMode, int key) {
    const type *characters[] = { //character list to try to add
        "A", "a", "B", "b", "C", "c", "D", "d", "E", "e",
        "F", "f", "G", "g", "H", "h", "I", "i", "J", "j",
        "K", "k", "L", "l", "M", "m", "N", "n", "O", "o",
        "P", "p", "Q", "q", "R", "r", "S", "s", "T", "t",
        "U", "u", "V", "v", "W", "w", "X", "x", "Y", "y",
        "Z", "z", "Á", "á", "Â", "â", "Ã", "ã", "À", "à",
        "Ç", "ç", "É", "é", "Ê", "ê", "Í", "í", "Ó", "ó",
        "Ô", "ô", "Õ", "õ", "Ú", "ú"
    };

    int length = strlen(word);
    
    for (int i = 0; i <= length; i++) { //erro aqui?
        // Loop body
        for (int j = 0; j < 76; j++) { // ADD
            VerifySugestion(dictionary, sugTable, word, hashingMode, i, characters[j], ADD_MODE, key);
        }

        if (length >= i + 1) { // REM
            VerifySugestion(dictionary, sugTable, word, hashingMode, i, NULL, REM_MODE, key);
        }

        if (length >= i + 2) { // SWAP
            VerifySugestion(dictionary, sugTable, word, hashingMode, i, NULL, SWAP_MODE, key);
        }
    } 
}

table *CreateSugestionsTable(text *txtToCorrect, table *dictionary, int hashingMode){ //make a table out of the validated suggestions
    int size = txtToCorrect->nWords * 3;
    table *sugestionsTable = InitTable(size, TABLE_TYPE_SUGESTIONS);

    if (sugestionsTable == NULL){
        printf("Out of Memory!\n");

        FreeTable(dictionary);

        for (int i = 0; i < txtToCorrect->nWords; i++){
            free(txtToCorrect->finalText[i]);

        }

        free(txtToCorrect->finalText);
        free(txtToCorrect);

        return NULL;

    }

    for (int i = 0; i < txtToCorrect->nWords; i++){
        if (!CheckWord(dictionary, txtToCorrect->finalText[i], LINEAR_ACCESS)){ 
            if (!CheckWord(sugestionsTable, txtToCorrect->finalText[i], QUADRATIC_ACCESS)){ //if the word isn't in the dictionary nor in the sugestion table, add it
                int key = 0;

                key = InsertItem(sugestionsTable, txtToCorrect->finalText[i], sugestionsTable->sugElements, hashingMode, INSERT_FIRST_TIME, EMPTY_SLOT); //inserting in sugestion table
                
                CreateSugestions(txtToCorrect->finalText[i], dictionary, sugestionsTable, hashingMode, key); //create the suggestions for the word

                Rehash(sugestionsTable, hashingMode); //check for rehash

            }

        }
        else{
            printf("The word '%s' is correct!\n", txtToCorrect->finalText[i]); //if the word exists in the dictionary, no need to do anything

        }

    }

    return sugestionsTable;

}


void CreateOutputFile(table *sugestionsTable, type *fileName){ //creating a file to display the suggestions found for the words in the file
    FILE *file = fopen((char *)fileName, "w");

    for (int i = 0; i < sugestionsTable->size; i++){
        if (sugestionsTable->sugElements[i].key != EMPTY_SLOT && sugestionsTable->sugElements[i].key != DELETED_SLOT){ //if its a valid key
            fprintf(file, "%s -> %s\n", sugestionsTable->sugElements[i].words->finalText[0], sugestionsTable->sugElements[i].words->finalText[1]);

            for (int j = 1; j < sugestionsTable->sugElements[i].nSugestions; j++){
                fprintf(file, "%s -> %s\n", sugestionsTable->sugElements[i].words->finalText[0], sugestionsTable->sugElements[i].words->finalText[j + 1]);

            }

        }

    }

    fclose(file);

}


int main(){
    setlocale(LC_ALL, "pt");

    type dicName[MAX_WORD_SIZE], textName[MAX_WORD_SIZE];
    int size = TABLE_SIZE;
    table *dic = InitTable(size, TABLE_TYPE_ITEM);

    printf("Insert dictionary file: "); scanf("%59s", dicName);
    printf("Insert text file: "); scanf("%59s", textName);

    printf("- - - - = = = = | P R O C E S S   S T A R T | = = = = - - - -\n\n");
    InitFile(dicName, dic, LINEAR_ACCESS); 
    printf("\n- - - - = = = = | P R O C E S S   E N D | = = = = - - - -\n\n");
    
    //PrintTable(dic);

    text *newText = GetTextWords(textName, SIZED_TEXT);

    table *sugTable = CreateSugestionsTable(newText, dic, QUADRATIC_ACCESS);

    PrintTable(sugTable);

    CreateOutputFile(sugTable, "OutputFile.txt");

    printf("\n\nFinished the program with success!\n\n");
    
    return 0;

}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   