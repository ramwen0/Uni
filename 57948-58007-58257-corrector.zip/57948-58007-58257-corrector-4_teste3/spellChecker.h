#ifndef SPELLCHECK_H
#define SPELLCHECK_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <stdbool.h>
#include <math.h>

typedef unsigned char type;

// Other
#define TABLE_SIZE 30 // goal for dic - 459998
#define REHASHING_LIM 0.65 // limit load factor to rehash

// Text
#define MAX_WORD_SIZE 60 // maximum word size
#define MAX_TEXT_SIZE 100 // maximum words

// Error Messages
#define ERROR_FILE "couldn't open file"

// Flags - keys
#define EMPTY_SLOT -1 // flag for empty key
#define DELETED_SLOT -2 // flag for deleted key

// Flags - text allocation
#define MAX_SIZE_TEXT 0
#define SIZED_TEXT 1

// Flags - Hashing Functions
#define LINEAR_ACCESS 0
#define QUADRATIC_ACCESS 1

// Flags - Table type
#define TABLE_TYPE_ITEM 0
#define TABLE_TYPE_SUGESTIONS 1

// Flags - Sugestions Rules
#define ADD_MODE 0
#define REM_MODE 1
#define SWAP_MODE 2

// Flags - Insert Mode
#define INSERT_FIRST_TIME 0
#define INSERT_NORMAL 1

// Struct definitions for first table
typedef struct hashItem{
    int key;
    type *word;

} item;

typedef struct hashText{
    type **finalText;
    int nWords;

} text;

typedef struct hashSugestions{
    int key;
    int nSugestions;
    text *words;

} sugestions;

typedef struct hashTable{
    int size; // size of table
    int count; //number of entries
    int rpCount; // repeated counter
    float lf; //load factor
    int rhCount; // rehashes counter
    int type;
    item *itemElements; //elements is the array of the table
    sugestions *sugElements; //elements is the array of the table

} table;


// Function prototypes - utilities
int CheckPrime(int n);
int GreatestPrime(int size);
item ModifyItem(int newKey, const type *newWord);
int GenerateKey(const type *word, int attempt, int size, int mode);

// Function prototypes - tables
table *InitTable(const size_t tableSize, int type);
void FreeTable(table *ht);
void PrintTable(table *ht);
void Rehash(table *ht, int mode);

// Function prototypes - items
int InsertItem(table *ht, type *word, sugestions *sug, int hashingMode, int insertMode, int ogKey);
void DeleteItem(table *ht, const int key);

// Function prototypes - word checking
int CheckWord(table *ht, const type *word, int mode);
type **AllocateText(int textSize, int wordSize);
text *GetTextWords(type *fileName, int textAllocationMode);

// Function prototypes - file handling
void InitFile(type *fileName, table *ht, int mode);
text *InitText(int textSIze, int wordSize, int allocationMode);

// Function prototypes - suggestion generation
type *AddSugestion(type *word, int position, const type *cAdd);
type *RemSugestion(type *word, int position);
type *SwapSugestion(type *word, int position);

// Function prototypes - suggestion handing and output
void VerifySugestion(table *dictionary, table *sugTable, type *word, int hashingMode, int position, const type *charAddition, int sugRule, int key);
void CreateSugestions(type *word, table *dictionary, table *sugTable, int hashingMode, int key);
table *CreateSugestionsTable(text *txtToCorrect, table *dictionary, int hashingMode);

void CreateOutputFile(table *sugestionsTable, type *fileName);

#endif
